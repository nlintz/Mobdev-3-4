package com.example.foodtweet;

import java.util.ArrayList;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    ArrayList<Tweet> tweets = getTweets("android", 1);
    
    ListView listView = (ListView) findViewById(R.id.ListViewId);
    TweetItemAdapter adapter = new TweetItemAdapter(this, R.layout.listitem, tweets);
    //listView.setAdapter(adapter);

    public ArrayList<Tweet> getTweets(String searchTerm, int page) {
		String searchUrl = "http://search.twitter.com/search.json?q=@" + searchTerm + "&rpp=100&page=" + page;
		
		ArrayList<Tweet> tweets = new ArrayList<Tweet>();
		HttpClient client = new DefaultHttpClient();
		HttpGet get = new HttpGet(searchUrl);
		
		ResponseHandler<String> responseHandler = new BasicResponseHandler();
		String responseBody = null;
		try {
			responseBody = client.execute(get, responseHandler);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		JSONObject jsonObject = null;
		JSONParser parser = new JSONParser();
		
		try {
			Object obj = parser.parse(responseBody);
			jsonObject = (JSONObject)obj;
		}catch (Exception e) {
			Log.v("TEST","EXCEPTION: " + e.getMessage());
		}
		
		JSONArray arr = null;
		
		try {
			Object j = jsonObject.get("results");
			arr = (JSONArray)j;
		} catch(Exception e){
			Log.v("TEST","EXCEPTION: " + e.getMessage());
		}
		
		for(int i=0;i < arr.length();i++) {
			JSONObject t = arr.getJSONObject(i);
			Tweet tweet = new Tweet(
					((JSONObject)t).get("from_user").toString(),
					((JSONObject)t).get("text").toString()
					);
			tweets.add(tweet);
		}
		
		
		return tweets;
	}

}
