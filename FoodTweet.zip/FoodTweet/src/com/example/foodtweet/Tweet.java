package com.example.foodtweet;


public class Tweet {
	public String username;
	public String message;
	
	public Tweet(String username, String message){
		this.username = username;
		this.message = message;
	}
	
	
}